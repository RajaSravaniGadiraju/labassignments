package com.cg.eis.bean.lab5;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.Serializable;

import com.cg.eis.exception.lab5.EmployeeException;
//Serialization is done for Lab Assignment 9.3
public class Employee5_1 implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int id;
	String name; 
	int  salary;
	String designation;
	String insuranceScheme;
	String str;
	
	//constructors
	
	  public Employee5_1() {
		super();
		// TODO Auto-generated constructor stub
	  }

	
	public Employee5_1(int id, String name, int salary, String designation) throws EmployeeException {
		super();
		//for program 6.3
		if(salary<3000)
		{
			throw new EmployeeException(); 
		}
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		}
	//getters and setters
	public int getSalary() 
	{
		return salary;
	}
	
	public void setSalary(int salary) throws EmployeeException {
	//for program lab 6.3
		if(salary<3000)
		{
			throw new EmployeeException();
		}
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	@Override
	public String toString() {
		return "Employee5_1 [id=" + id + ", name=" + name + ", salary=" + salary + ", designation=" + designation
				+ ", insuranceScheme=" + insuranceScheme + "]";
	}


}