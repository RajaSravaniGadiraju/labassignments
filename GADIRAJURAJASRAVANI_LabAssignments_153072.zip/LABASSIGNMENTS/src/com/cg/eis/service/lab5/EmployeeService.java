package com.cg.eis.service.lab5;

import com.cg.eis.bean.lab5.Employee5_1;

public interface EmployeeService {
	
		public abstract void details(Employee5_1 emp);
		
	}

