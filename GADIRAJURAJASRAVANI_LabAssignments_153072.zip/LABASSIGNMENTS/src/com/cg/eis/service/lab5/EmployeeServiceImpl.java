
package com.cg.eis.service.lab5;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.cg.eis.bean.lab5.Employee5_1;

public class EmployeeServiceImpl extends Employee5_1 implements EmployeeService
{
@Override
public void details(Employee5_1 emp) 
{
	if(emp.getSalary()<5000)
			{
		
				emp.setInsuranceScheme("No scheme");
				
			}
	
    else if(emp.getSalary()>5000 && emp.getSalary()< 20000)
			{
			
				emp.setInsuranceScheme("Scheme C");
			}
   else if(emp.getSalary()>=20000 && emp.getSalary()<40000)
			{
				
				emp.setInsuranceScheme("Scheme B");
				
			}
   else
			{
				
				emp.setInsuranceScheme("Scheme A");
				
		
			}
// File Lab9_3 I/O File; Using FileWriterReader & BufferedReaderWriter
	try
	{
				
       FileWriter fw=new FileWriter("D:\\employee.txt",true);
	   BufferedWriter bw=new BufferedWriter(fw);
	   String str=emp.getId()+"\t"+emp.getName()+"\t"+emp.getDesignation()+"\t"+emp.getInsuranceScheme();
				
	   bw.write(str);
				
	   bw.newLine();
				
	   bw.close();
				
	}
	catch(Exception e)
			
	{
	     e.printStackTrace();
	}
		
  }		
}
		

	




