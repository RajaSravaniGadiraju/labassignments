package com.cg.eis.pl.lab5;

import com.cg.eis.bean.lab5.Employee5_1;
import com.cg.eis.exception.lab5.EmployeeException;
import com.cg.eis.service.lab5.EmployeeService;
import com.cg.eis.service.lab5.EmployeeServiceImpl;

public class User {

	public static void main(String[] args) throws EmployeeException {
		EmployeeService e = new EmployeeServiceImpl();
		Employee5_1 emp1 = new Employee5_1(101, "Sravani", 30000, "Programmer");
		e.details(emp1);
		System.out.println(emp1);

		Employee5_1 emp2 = new Employee5_1(102, "Mounika", 20000, "Programmer");
		e.details(emp2);
		System.out.println(emp2);
		Employee5_1 emp3 = new Employee5_1(103, "Lakshmi", 4000, "Clerk");
		e.details(emp3);
		System.out.println(emp3);
		Employee5_1 emp4 = new Employee5_1(104, "Daneswari", 60533, "Manager");
		e.details(emp4);
		System.out.println(emp4);

	}
}
		
		
		
		

	
		
		

