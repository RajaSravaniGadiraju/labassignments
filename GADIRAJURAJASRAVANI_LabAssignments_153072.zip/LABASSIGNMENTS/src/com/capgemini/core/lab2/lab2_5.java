package com.capgemini.core.lab2;

public class lab2_5 
{
	public static void main(String[] args) {
		Enumlab2_5 list=new Enumlab2_5("Sravani", "Gadiraju");
		list.setPhonenumber (9010859483l);
		list.printDetails();
		list.gendercheck(Gender.F);
		
	}
}
