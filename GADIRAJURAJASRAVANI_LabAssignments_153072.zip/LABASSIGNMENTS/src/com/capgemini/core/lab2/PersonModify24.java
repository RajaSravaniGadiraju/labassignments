package com.capgemini.core.lab2;

public class PersonModify24 
{
	public static void main(String args[]) {
		Person24 pe = new Person24( "Divya","Bharathi",'F');
		pe.setPhonenumber("9010859489");
		pe.printPersonDetails();
	}

 }

