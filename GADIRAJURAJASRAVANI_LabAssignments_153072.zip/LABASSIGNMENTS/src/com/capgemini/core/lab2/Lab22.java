package com.capgemini.core.lab2;

public class Lab22
{
 public static void main(String args[])
 {
	int number = Integer.parseInt(args[0]);
	if(number >= 0)
	 {
		 System.out.println("positive");
	 }
	 else
	 {
		 System.out.println("negative");
	 }
 }
}
