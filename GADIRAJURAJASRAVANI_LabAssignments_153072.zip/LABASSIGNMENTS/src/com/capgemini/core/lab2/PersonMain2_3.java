package com.capgemini.core.lab2;

public class PersonMain2_3 {
	public static void main(String args[]) {
		Person2_3 pe= new Person2_3( "Divya","Bharathi",'F');
		System.out.println("FirstName : " +pe.getFirstName());
		System.out.println("LastName : " +pe.getLastName());
		System.out.println("Gender : " +pe.getGender());
	}

	
}
