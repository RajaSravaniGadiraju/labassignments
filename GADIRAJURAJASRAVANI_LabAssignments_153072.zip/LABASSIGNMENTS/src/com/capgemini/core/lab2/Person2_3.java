package com.capgemini.core.lab2;
//class name
public class Person2_3 
{ 
	//Intilization
   String FirstName;
   String LastName;
   char Gender;
   //constructors
public Person2_3(String FirstName, String LastName, char Gender) {
	super();
	this.FirstName = FirstName;
	this.LastName = LastName;
	this.Gender = Gender;
}
//getters and setters
public String getFirstName() {
	return FirstName;
   }
public void setFirstName(String FirstName) {
	this.FirstName = FirstName;
   }
 public String getLastName() {
	return LastName;
   }
public void setLastName(String LastName) {
	this.LastName = LastName;
   }
public char getGender() {
	return Gender;
   }
public void setGender(char gender) {
	Gender = gender;
   }
public void setPhonenumber() {
	// TODO Auto-generated method stub
	
}
}



