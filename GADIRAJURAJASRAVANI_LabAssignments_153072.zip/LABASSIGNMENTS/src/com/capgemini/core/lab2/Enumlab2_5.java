package com.capgemini.core.lab2;
import java.util.Scanner;


enum Gender
{
	m,f,F,M;
}


public class Enumlab2_5 
{
	String FirstName;
	String LastName;
	long Phonenumber;
	public Enumlab2_5()
	{
		super();
	}
	public Enumlab2_5(String firstName, String lastName) {
		super();
		FirstName = firstName;
		LastName = lastName;
		
	}
	
	public void gendercheck(Gender gender)

	{
		switch(gender)
		{
		case F:
			System.err.println("Gender:Female");
			break;
		case M:
			System.err.println("Gender:Male");
			break;
		case f:
			System.err.println("Gender:Female");
			break;
		case m:
			System.err.println("Gender:Male");
			break;
		
		}
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public long getPhonenumber() {
		return Phonenumber;
	}
	public void setPhonenumber(long phonenumber) {
		Phonenumber = phonenumber;
	}
	
	public void printDetails() {
		
		System.out.println("Personal Details");
		System.out.println("---------");
		System.out.println("FirstName"+FirstName);
		System.out.println("LastName"+LastName);
		System.out.println("Phonenumber"+Phonenumber);
		
		
	}
	
	
	

}
