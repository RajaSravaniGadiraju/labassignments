package com.capgemini.core.lab2;

public class Person24 {
	String FirstName;
    String LastName;
    char Gender;
    String Phonenumber;
	public Person24(String firstName, String lastName, char gender) {
		super();
		FirstName = firstName;
		LastName = lastName;
		Gender = gender;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public char getGender() {
		return Gender;
	}
	public void setGender(char gender) {
		Gender = gender;
	}
	public String getPhonenumber() {
		return Phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		Phonenumber = phonenumber;
	}
	public void printPersonDetails()
	{
		System.out.println("PersonalDetails");
		System.out.println("________________");
		System.out.println("FirstName : " +FirstName);
		System.out.println("LastName : " +LastName);
		System.out.println("Gender : " +Gender);
		System.out.println("Phonenumber : " +Phonenumber);
	}
}
