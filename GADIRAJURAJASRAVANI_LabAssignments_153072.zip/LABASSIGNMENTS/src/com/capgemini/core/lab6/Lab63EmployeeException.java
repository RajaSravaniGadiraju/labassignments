package com.capgemini.core.lab6;

public class Lab63EmployeeException extends Exception {
	
	public String getMessage() {
		return"Salary should be greater than 3000";
	}

}
