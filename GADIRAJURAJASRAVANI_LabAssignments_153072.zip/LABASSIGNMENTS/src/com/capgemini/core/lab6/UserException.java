package com.capgemini.core.lab6;

public class UserException extends Exception {
	public String getMessage()
	{
		return "Name not Valid";
	}

}
