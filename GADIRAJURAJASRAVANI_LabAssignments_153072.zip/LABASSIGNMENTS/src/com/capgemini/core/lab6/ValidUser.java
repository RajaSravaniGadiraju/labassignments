package com.capgemini.core.lab6;

public class ValidUser 
{
	public static void main(String[] args) throws UserException
	{
		Lab6_1 o=new Lab6_1("SARATH","","M");
		if(o.firstname.equals(""))
		{
			throw new UserException();
		}
		if(o.lastname.equals(""))
		{
			throw new UserException();
		}
		System.out.println(o);
	}

}
