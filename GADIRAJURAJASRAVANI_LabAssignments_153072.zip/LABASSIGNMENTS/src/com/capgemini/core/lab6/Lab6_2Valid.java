package com.capgemini.core.lab6;
import java.util.Scanner;

public class Lab6_2Valid
{
	public static void main(String[] args) throws Lab62_UserException {
		Lab6_2 k=new Lab6_2();
		int age;
		Scanner c= new Scanner(System.in);
		age=c.nextInt();
		
		if (age<15 && age<0)
		{
			throw new Lab62_UserException();
			
		}
		else
		{System.out.println("Age of a person"+age);
		
		}
	}

}
