package com.capgemini.core.lab6;

public class Lab62_UserException extends Exception {
	
	public String getMessage()
	{
		return "AGE NOT VALID";
		
	}

}
