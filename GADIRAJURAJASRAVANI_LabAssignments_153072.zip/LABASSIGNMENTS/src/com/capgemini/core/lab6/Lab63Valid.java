package com.capgemini.core.lab6;

import java.util.Scanner;

public class Lab63Valid extends Lab63 
{
	public static void main(String[] args) throws Lab63EmployeeException
	{
		Scanner h=new Scanner(System.in);
		Lab63 e1=new Lab63();
		System.out.println("Enter your id");
		e1.setId(h.nextInt());
		System.out.println("Enter your name");
		e1.setName(h.next());
		System.out.println("Enter your Salary");
		double db=h.nextDouble();
		e1.setSalary(db);
		if(db<3000)
			throw new Lab63EmployeeException();
		System.out.println("Enter your designation");
		e1.setDesignation(h.next());
		System.out.println(e1);
		
		
	}

}
