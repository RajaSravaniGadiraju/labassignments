package com.capgemini.core.lab7;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumMap;

import com.capgemini.core.lab7.Employeelab7_6;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

	public class EmployeeServiceImpl7_6{
		static Map<Integer, Employeelab7_6> map = new HashMap<Integer, Employeelab7_6>();
		static Employeelab7_6 e1 = new Employeelab7_6("sravani", 20000, "Programmer", "Scheme B");
		static Employeelab7_6 e2 = new Employeelab7_6("daneswari", 24000, "Programmer", "Scheme B");
		static Employeelab7_6 e3 = new Employeelab7_6("satya", 2000, "Clerk", "No Scheme");

		// Add Employee details
		public void addEmployee() {

			map.put(101, e1);
			map.put(102, e2);
			map.put(103, e3);

		}

		// Search for employee
		public void searchEmp() {
			Scanner sc = new Scanner(System.in);
			String insuranceScheme;
			System.out.println("Enter the insurance scheme");
			insuranceScheme = sc.nextLine();
			Set set = map.entrySet();
			Iterator i = set.iterator();

			while (i.hasNext()) {

				Map.Entry me = (Map.Entry) i.next();

				if (insuranceScheme.equalsIgnoreCase(((Employeelab7_6) me.getValue()).getScheme())) {

					System.out.println("the employee is searched : \n" + me.getKey() + ":" + (me.getValue().toString()));
				}

			}
		}

		public void deleteEmployee(int id) {

			map.remove(id);

		}

		public void display() {
			Set set = map.entrySet();
			Iterator k = set.iterator();
			while (k.hasNext()) {

				Map.Entry me = (Map.Entry) k.next();
				System.out.println(me.getKey() + " : " + (me.getValue()));
			}
		}

		private static void sortMapByValues(Map<Integer, Employeelab7_6> map) {
			Set<Entry<Integer, Employeelab7_6>> mapEntries = map.entrySet();
			// To sort create a linked list
			List<Entry<Integer, Employeelab7_6>> alist = new LinkedList<Entry<Integer, Employeelab7_6>>(mapEntries);
			Collections.sort(alist, new Comparator<Entry<Integer, Employeelab7_6>>() {

				@Override
				public int compare(Entry<Integer, Employeelab7_6> s1, Entry<Integer, Employeelab7_6> s2) {

					if (s1.getValue().getSalary() > s2.getValue().getSalary()) {
						//System.out.println("Sorting in progress");
						return 1;
					} else {
						return -1;
					}
				}

			});
			Map<Integer, Employeelab7_6> sortedMap = new LinkedHashMap<Integer, Employeelab7_6>();
			for (Entry<Integer, Employeelab7_6> entry : alist) {
				sortedMap.put(entry.getKey(), entry.getValue());
				System.out.println("Key : " + entry.getKey() + "\t" + " Value : " + entry.getValue());
			}
		}

		public static void main(String[] args) {
			EmployeeServiceImpl7_6 n = new EmployeeServiceImpl7_6();
			// n.addEmployee();
			// n.searchEmp();

			String ans;
			int c;
			Scanner sc1 = new Scanner(System.in);

			do {
				System.out.println(
						"1. Add Details\n2. Search employee using Insurance scheme\n3. Delete employee using Id\n4. Display\n5.Sort on the basis of Salary");
				System.out.println("Enter choice");
				c = sc1.nextInt();
				switch (c) {
				case 1:
					n.addEmployee();
					System.out.println("Employee added");
					break;
				case 2:
					n.searchEmp();
					break;
				case 3:
					System.out.println("Enter the id of employee u want to delete");

					int id = sc1.nextInt();
					n.deleteEmployee(id);
					System.out.println("Employee deleted");
					break;
				case 4:
					n.display();
					break;
				case 5:
					sortMapByValues(map);
					// sortEmp t = new sortEmp();
					break;
					default:
						System.out.println("Error");

				}

				System.out.println("Do u want to continue?");

				ans = sc1.next();
			}

			while (ans.equalsIgnoreCase("yes") || ans.equalsIgnoreCase("y"));

		}

	}


