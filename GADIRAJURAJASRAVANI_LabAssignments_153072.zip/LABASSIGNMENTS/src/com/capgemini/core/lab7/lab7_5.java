package com.capgemini.core.lab7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class lab7_5 
{
    public static void main(String[] args) 
    {
		List<String> list=new ArrayList<String>();
		list.add("hello");
		list.add("hi");
		list.add("how");
		
		list.add("are");
		list.add("you");
		list.add("what");
		Collections.sort(list);
		for(String s:list)
		{
			System.out.println(s);
		}
	}
}
