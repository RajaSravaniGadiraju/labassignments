package com.capgemini.core.lab7;

import java.util.HashMap;
import java.util.Map;

public class lab7_4 
{
  static int[] array= {10,11,12,13};
  static HashMap map = new HashMap();
  public static void main(String[] args)
  {
	  for(int i=0;i<array.length;i++)
	  {
		  System.out.println(array[i]);
	  }
	  Map l=getSquares(array);
	  System.out.println(l);
  }
   @SuppressWarnings("unchecked")
public static Map getSquares(int []array)
   {
	   for(int i=0;i<array.length;i++)
	   {
		 map.put(array[i], (array[i]*array[i]));
	   }
	   return map;
}
}
