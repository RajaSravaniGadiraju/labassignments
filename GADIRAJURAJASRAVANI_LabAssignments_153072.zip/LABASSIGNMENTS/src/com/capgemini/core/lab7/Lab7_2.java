package com.capgemini.core.lab7;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Lab7_2
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str1,str2;
		System.out.println("Enter two Strings");
		str1=sc.next();
		str2=sc.next();
		List<String> list=new ArrayList<String>();
		Operations op=new Operations();
		String res=op.AltString(str1,str2);
		list.add(res);
		System.out.println(list);
	}
}
class Operations
{
	public String AltString(String ptr1,String ptr2)
	{
		char[]ch1=ptr1.toCharArray();
		char[]ch2=ptr2.toCharArray();
		int i=0;
		for(i=0;i<ch1.length;i+=2)
		{
			ch1[i]=ch2[i];
		}
		String ptr=String.valueOf(ch1);
		return ptr;
	}
}