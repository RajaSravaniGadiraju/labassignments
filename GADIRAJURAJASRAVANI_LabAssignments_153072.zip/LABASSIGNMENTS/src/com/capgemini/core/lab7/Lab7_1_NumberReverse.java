package com.capgemini.core.lab7;

import java.util.Arrays;
import java.util.Scanner;

public class Lab7_1_NumberReverse 
{
     public static void main(String[] args) {
		int[] number= new int[5];
		String[] numberReverse = new String[5];
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number");
		for(int i=0;i<number.length;i++)
		{
			number[i]=sc.nextInt();
			numberReverse[i]=Integer.toString(number[i]);
		}
		for(int i=0;i<number.length;i++)
			numberReverse[i]=new StringBuilder(numberReverse[i]).reverse().toString();
		Arrays.sort(numberReverse);
		System.out.println("Reversing a number");
		for(int i=0;i<number.length;i++)
			System.out.println(""+numberReverse[i]);
	}
}
