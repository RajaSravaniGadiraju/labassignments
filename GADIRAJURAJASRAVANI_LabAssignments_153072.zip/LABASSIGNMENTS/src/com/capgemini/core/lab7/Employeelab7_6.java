package com.capgemini.core.lab7;

public class Employeelab7_6
{

private String name;
private int salary;
private String designation;
private String scheme;
//For Program 7.6
public Employeelab7_6(String name, int salary,String designation, String scheme) {
	this.name = name;
	this.salary = salary;
	this.designation = designation;
	this.scheme=scheme;
}
			
            public String getName() {
				return name;
			}



			public void setId(String name) {
				this.name = name;
			}



			public int getSalary() {
				return salary;
			}



			public void setSalary(int salary) {
				this.salary = salary;
			}



			public String getDesignation() {
				return designation;
			}



			public void setDesignation(String designation) {
				this.designation = designation;
			}



			public String getScheme() {
				return scheme;
			}



			public void setScheme(String scheme) {
				this.scheme = scheme;
			}



			@Override
			public String toString() {
				return "name=" + name + ", salary=" + salary + ", designation=" + designation + ", scheme=" + scheme;
			}

	}

