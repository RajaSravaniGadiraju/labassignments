package com.capgemini.core.lab7;
// common names will be eliminated in two list
import java.util.ArrayList;
import java.util.List;

public class lab7_3 
{
  public static void main(String[] args) {
	List<String> list = new ArrayList<String>();
	list.add("sravani");
	list.add("raju");
	list.add("lakshmi");
	
	List<String> list1=new ArrayList<String>();
	list1.add("satya");
	list1.add("raju");
	list1.add("ranga");
	
	List<String> intersection=new ArrayList<String>(list);
	intersection.retainAll(list1);
	list.removeAll(intersection);
	for(String s:list)
	{
		System.out.println(s);
	}
}
}
