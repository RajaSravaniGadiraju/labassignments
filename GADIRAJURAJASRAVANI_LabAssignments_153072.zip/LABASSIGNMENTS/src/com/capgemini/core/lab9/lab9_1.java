package com.capgemini.core.lab9;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

public class lab9_1 
{
	public static void main(String[] args) 
	{
        try
           {
            	FileReader previousFile=new FileReader("D:\\sravani.txt");
	            BufferedReader bufferReader=new BufferedReader(previousFile);
	            String line="";
	            FileWriter newFile=new FileWriter("D:\\sravaniNew.txt");
	            while(line!=null)
	               {
		            line=bufferReader.readLine();
		            if(line!=null)
		           {
			          StringBuilder strb=new StringBuilder(line);
			          String str=strb.reverse().toString();
			          newFile.write(str);
			
		           }
	       }
	      previousFile.close();
	      newFile.close();
        }
      catch(Exception e)

         {
	            e.printStackTrace();
         }
     }

}
