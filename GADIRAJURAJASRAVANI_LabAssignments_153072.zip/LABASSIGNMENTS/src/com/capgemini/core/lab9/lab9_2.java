package com.capgemini.core.lab9;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class lab9_2
{
	public static void main(String[] args) throws FileNotFoundException 
	{
		
	
       File filename=new File("D:\\numbers.txt");
       Scanner scanner=new Scanner(filename);

       int line=0;
       int[] check=new int[10];
       while(scanner.hasNext())
       {
	
	        String string=scanner.nextLine();
	        String[] string1=string.split(",");
	        for(String obj:string1)
	           {
		               System.out.print(obj+"\n");
	           }
	          System.out.println("even numbers are:");

	         for(int i=0;i<10;i++)
	              {
		     check[i]=Integer.parseInt(string1[i]);
		     if(check[i]%2==0)
		          {
			         System.out.println(check[i]);
		          }
	    }
	
       }
	
       scanner.close();   

    }
	
}


 




