package com.capgemini.core.lab3;

import java.util.*
;

public class lab3_8 
{
	public static void main(String[] args) {
		
	
     int length;
     System.out.println("enter number of strings");
     Scanner sc = new Scanner(System.in);
     int n=sc.nextInt();
     String names[]=new String[n];
     Scanner sc1=new Scanner(System.in);
     for(int i=0;i<n;i++) 
      {
    	 names[i] = sc1.nextLine();
      }
     for(int i=0;i<n;i++)
     {
    	 for(int j=i+1;j<n;j++)
    	 {
    		 if(names[i].compareTo(names[j])>0)
    		 {
    			 String temp=names[i];
    			 names[i]=names[j];
    			 names[j]=temp;
    		 }
    	 }
     }
    if(n%2==0)	 
    {
    	length=n/2;
    	for(int i=0;i<length;i++)
    	{
    		names[i]=names[i].toUpperCase();
    		System.out.println(names[i]);
    	}
    	
    }
    else
    {
    	length=n/2+1;
    	for(int i=0;i<length;i++)
    	{
    		names[i]=names[i].toUpperCase();
    	}
    	for(int i=0;i<n;i++)
    	{
    		System.out.println(names[i]);
    	}
      }
	}
   
}
	
