package com.capgemini.core.lab3;

import java.util.Scanner;

public class lab3_2 
{
 public static void main(String[] args) {
	int flag=0;
	System.out.println("enter string:");
	Scanner sc=new Scanner(System.in);
	String input=sc.nextLine();
	String str=input.toLowerCase();
	int [] array = new int[str.length()];
	for(int i=0;i<str.length();i++) {
		array[i]=(int)str.length();
			
	}
   for(int i=0;i<str.length()-1;i++)
   {
	   if(array[i]>array[i+1])
	   {
		   flag=1;
	   }
   }
   
   if(flag==1)
   {
	   System.out.println("positive string");
   }
   else
   {
	   System.out.println("negative string");
   }
}
}