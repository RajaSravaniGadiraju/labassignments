package com.capgemini.core.lab3;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class lab3_3 
{
	public static void main(String[] args) {
		
	
     Scanner sc = new Scanner(System.in);
     
     System.out.println("enter date in the format yyyy/MM/dd");
     String str = sc.nextLine();
     
     String[] str1 = str.split("/");
     
     int year = Integer.parseInt(str1[0]);
     int month = Integer.parseInt(str1[1]);
     int days = Integer.parseInt(str1[2]);
     
     LocalDate date = LocalDate.now();
     LocalDate date1 = LocalDate.of(year, month, days);
     Period period = date.until(date1);
     
     Period difference = Period.between(date,date1);
     System.out.println("difference :" +difference);
     
	}
}
