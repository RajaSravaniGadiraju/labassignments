package com.capgemini.core.lab3;

import java.util.*;

public class lab3_7
{
	private static final int len = 0;

	public static void main(String[] args) {
		
	
   Scanner sc = new Scanner(System.in);
   String input=sc.nextLine();
   char[] letters = input.toCharArray();
   int len=letters.length;
   String res="_job";
   char[] test = res.toCharArray();
   boolean result=check(letters,test,len);
   System.out.println(result);

	}

	private static boolean check(char[] a, char[] b, int c) {
		int flag=0;
		if(a.length<12) {
			return false;
		}
		else {
			int j=0;
			for(int i=len-4;i<len;i++)
			{
			    if(a[i]==b[j])
			    	flag=1;
			 j++;
			}
		}
		if(flag==1)
			return true;
		else
		return false;
	}
	
   
}
