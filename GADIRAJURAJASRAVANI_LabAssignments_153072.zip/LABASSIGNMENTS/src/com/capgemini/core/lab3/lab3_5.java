package com.capgemini.core.lab3;

import java.time.LocalDate;
import java.util.Scanner;

public class lab3_5 
{
     public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		LocalDate date = LocalDate.now();
		System.out.println("enter the warrenty period in y/m");
		
		String str = sc.nextLine();
		String[] str1 = str.split("/");
		
		int years = Integer.parseInt(str1[0]);
		int months = Integer.parseInt(str1[1]);
		System.out.println("warrenty date is:");
		date = date.plusYears(years);
		
		System.out.println(date.plusMonths(months));
		
	}
}
