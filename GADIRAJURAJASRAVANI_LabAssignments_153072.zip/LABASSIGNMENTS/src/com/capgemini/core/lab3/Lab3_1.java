package com.capgemini.core.lab3;

public class Lab3_1 {
	//addition of strings
     public void add(String str)
        {
	       System.out.println(str+str);
        }
    //replace
     public void replace(String str)
     {
    	 char []temp = str.toCharArray();
    	 for (int i=0; i<temp.length;i++)
    		 if(i%2 ==0)
    		 {
    			 System.out.print("#");
    		 }
    		 else
    			 System.out.print(temp[i]);
         }
     
   //replace
    public void duplicate(String str)
    {
    	String temp="";
    	for(int i=0;i<str.length();i++)
    	{
    		char ch=str.charAt(i);
    		if(ch!=' ')
    		{
    			temp=temp+ch;
    		}
    		str=str.replace(ch,' ');
    	}
    	System.out.println(temp);
    }
    //uppercase
    public void uppercase(String str)
    {
    	char []temp=str.toCharArray();
    	for(int i=0;i<temp.length;i++)
        {
    	  if(i%2==0)
    	  {
    		  System.out.print(Character.toUpperCase(temp[i]));
    	  }
    	  else
    		  System.out.print(temp[i]);
    	}
    }
    
}   




