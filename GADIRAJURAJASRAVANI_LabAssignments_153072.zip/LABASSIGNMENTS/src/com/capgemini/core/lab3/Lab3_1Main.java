package com.capgemini.core.lab3;

import java.util.Scanner;

public class Lab3_1Main {
	public static void main(String[] args) {
		Lab3_1 obj = new Lab3_1();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a string");
		String name=sc.nextLine();
		System.out.println("1.Add the String to itself");
		System.out.println("2.Replace odd positions with #");
		System.out.println("3.Remove duplicate characters in the String");
		System.out.println("4.Change odd characters to upper case");
		int choice = sc.nextInt(); 
		switch(choice)
		{
		case 1:
			obj.add(name);
			break;
		case 2:
			obj.replace(name);
			break;
		case 3:
			obj.duplicate(name);
			break;
		case 4:
			obj.uppercase(name);
			break;
		default:
			System.out.println("invalid option");
		}
		
	}

}
