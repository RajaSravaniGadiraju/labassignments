package com.capgemini.core.lab3;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class lab3_6 
{
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the zone id in:");
	    String str=sc.nextLine();
	    ZonedDateTime time = ZonedDateTime.now(ZoneId.of(str));
	System.out.println(time);
	}
	

}
