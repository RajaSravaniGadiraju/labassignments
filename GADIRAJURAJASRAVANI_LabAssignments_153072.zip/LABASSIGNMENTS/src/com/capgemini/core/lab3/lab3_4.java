package com.capgemini.core.lab3;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class lab3_4 {
	public static void main(String[] args) {
		
		
	     Scanner sc = new Scanner(System.in);
	     
	     System.out.println("enter date in the format yyyy/MM/dd");
	     String str = sc.nextLine();
	     String str1 = sc.nextLine();
	     
	     String[] strArray = str.split("/");
	     String[] strArray1 = str1.split("/");
	     
	     int year = Integer.parseInt(strArray[0]);
	     int month = Integer.parseInt(strArray[1]);
	     int days = Integer.parseInt(strArray[2]);
	     
	     int year1 = Integer.parseInt(strArray1[0]);
	     int month1 = Integer.parseInt(strArray1[1]);
	     int days1 = Integer.parseInt(strArray1[2]);
	     
	     LocalDate date = LocalDate.of(year1, month1, days1);
	     LocalDate date1 = LocalDate.of(year, month, days);
	     Period period = date.until(date1);
	     
	     Period difference = Period.between( date , date1 );
	     System.out.println("difference :"  + difference );
}
}