package com.capgemini.core.lab4;

public class Account41 extends Person41
{
      protected long accNum;
      protected double balance;
      Person41 accHolder;
	

	public Account41(String name,float age ,long accNum, double balance, Person41 accHolder) {
		super();
		this.accNum = accNum;
		this.balance = balance;
		this.accHolder = accHolder;
	}

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person41 getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person41 accHolder) {
		this.accHolder = accHolder;
	}

	//Transaction 
	
		public void deposit(double amount)
		{
			balance += amount;
		}
		 
		public void withdraw(double amount)
		{
			if(amount > balance )
			{
				System.out.println(" Insuffient Balance");
				return;
			}
			balance -= amount;
		}

		@Override
		public String toString() {
			return "Account41 [accNum=" + accNum + ", balance=" + balance + ", accHolder=" + accHolder + "]";
		}

}
