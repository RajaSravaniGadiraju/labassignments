package com.capgemini.core.lab4;

public class SavingsAccount42 extends Account41
{
   public SavingsAccount42(String name, float age, long accNum, double balance, Person41 accHolder) {
		super(name, age, accNum, balance, accHolder);
		// TODO Auto-generated constructor stub
	}
public final double minimumbalance = 500;
   public void withdraw(double amount)
   {
	  if(amount < minimumbalance) 
	     {
		   System.out.println("Amount is less than the minimum balance");
	     }
	   
	  else if(amount > balance) 
	     {
		   System.out.println("insufficient balance");
		   return;
	     }
	  else 
	     {
		   setBalance(getBalance()-amount);
	     }
   }
}

