package com.capgemini.core.lab4;

public class CurrentAccount42 extends Account41
{
  
   public CurrentAccount42(String name, float age, long accNum, double balance, Person41 accHolder) {
		super(name, age, accNum, balance, accHolder);
		// TODO Auto-generated constructor stub
	}
double temp;
	public void withdraw(double amount){
		if(amount>getBalance()+(getBalance()*0.1)){
			System.out.println("insufficient bbalance");
		}
		temp=getBalance()-amount;
		if(getBalance()-amount<0){
			setBalance(0);
		}
		else{
			setBalance(getBalance()-amount);
			}
}
}