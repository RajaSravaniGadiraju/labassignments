package com.capgemini.core.lab4;

import java.util.Random;

public class MainMethod41 
  {
    public static void main(String []args)
    {
    	Random rand = new Random();
    	long rand1=rand.nextLong();
    	long rand2=rand.nextLong();
        Person41 person1=new Person41("smith",45);
        Person41 person2= new Person41("kathy",40);
        Account41 account1= new Account41("smith",45,rand1,2000,person1);
        Account41 account2= new Account41("kathy",40,rand2,3000,person2);
        account1.deposit(2000);
        account2.withdraw(2000);
        account1.getBalance();
        account2.getBalance();
        System.out.println(account1);
        System.out.println(account2);
       }
    }
    	
    	
    	