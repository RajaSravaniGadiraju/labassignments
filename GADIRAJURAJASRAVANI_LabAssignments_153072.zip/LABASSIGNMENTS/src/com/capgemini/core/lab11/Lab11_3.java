package com.capgemini.core.lab11;

import java.util.Scanner;

public class Lab11_3 
{
	public static void main(String[] args) {
		Lab11_3_Interface lm1= (userName,password) ->
		{
						if(userName.equalsIgnoreCase("ADMIN") && password.equals("Admin@123"))
							return true;
						else
							return false;
		};
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Custom Username id ADMIN and password is Admin@123");
		System.out.println("Enter username");
		String userName=sc.next();
		System.out.println("Enter password");
		String passWord=sc.next();
		
		System.out.println(lm1.validation(userName, passWord));
	}
}
