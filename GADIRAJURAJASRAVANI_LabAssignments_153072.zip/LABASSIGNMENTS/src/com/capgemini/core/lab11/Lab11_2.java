package com.capgemini.core.lab11;

public class Lab11_2 
{
	public static void main(String[] args) {
		Lab11_2_Interface lamda= (string) ->
		{
			String temp="";
			for(int i=0;i<string.length();i++)
			{
				temp=temp+string.charAt(i) + " ";
			}
			return temp;
		};
		System.out.println(lamda.modifyString("Sravani"));
	}
}
