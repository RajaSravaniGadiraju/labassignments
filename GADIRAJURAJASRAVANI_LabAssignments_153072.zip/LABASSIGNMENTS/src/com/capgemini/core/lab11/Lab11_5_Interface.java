package com.capgemini.core.lab11;

public interface Lab11_5_Interface
{
public abstract void fact(int n);
}
