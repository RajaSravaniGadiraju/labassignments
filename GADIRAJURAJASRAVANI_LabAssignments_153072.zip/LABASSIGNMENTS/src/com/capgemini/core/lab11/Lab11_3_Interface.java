package com.capgemini.core.lab11;

public interface Lab11_3_Interface 
{
	public abstract boolean validation(String userName , String password);
}
