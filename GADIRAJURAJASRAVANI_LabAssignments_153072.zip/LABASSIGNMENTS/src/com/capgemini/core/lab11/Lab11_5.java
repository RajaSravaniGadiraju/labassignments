package com.capgemini.core.lab11;

import java.util.Scanner;

class Lab11_5 implements Lab11_5_Interface
{

	private int n;
	@Override
	public void fact(int n) {
		int f=1;
		for(int i=n;i>=1;i--)
		{
			f=f*i;
		}
		System.out.println("factorial is " +f);
		
	}

	public Lab11_5(int n)
	{
		super();
		this.n=n;
		fact(n);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the no.");
		int number=sc.nextInt();
		Lab11_5_Interface lamda=Lab11_5::new;
		lamda.fact(number);
	}

	}
