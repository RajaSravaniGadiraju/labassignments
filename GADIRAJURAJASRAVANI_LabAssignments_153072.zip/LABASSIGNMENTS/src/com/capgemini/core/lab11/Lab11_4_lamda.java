//11.4: Write a class with main method to demonstrate instance creation using method reference. (Hint: Create any simple class with attributes and getters and setters)
package com.capgemini.core.lab11;

class LambdaImpll_11_4 implements Lab11_4_InterfaceLamda
{
	int age;
	String name;
	int id;
	
	
	public LambdaImpll_11_4(int age, String name, int id) {
		super();
		this.age = age;
		this.name = name;
		this.id = id;
		Lab11_4_Person per = new Lab11_4_Person(age, name, id);
		System.out.println(per);
		
	}



	@Override
	public LambdaImpll_11_4 getLambdaImpll_11_4(int id, String name, int age) {
		return null;
	}

}


public class Lab11_4_lamda
{
	public static void main(String[] args) 
	{
	
			Lab11_4_InterfaceLamda lm = LambdaImpll_11_4::new; 
			lm.getLambdaImpll_11_4(21, "Sravani", 101);
			
		

		
	}
}