package com.capgemini.core.lab11;

public class Lab11_1 
{
		public static void main(String[] args) {
			Lab11_1_Interface exp=(n1,n2)->
			{
				String num1=""+n1;
				String num2=""+n2;
				return Math.pow(Double.parseDouble(num1), Double.parseDouble(num2));
			};
			
			System.out.println(exp.exponential(12,3));
		}

}
