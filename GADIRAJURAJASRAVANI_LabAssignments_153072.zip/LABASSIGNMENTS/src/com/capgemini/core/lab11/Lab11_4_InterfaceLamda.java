//11.4
package com.capgemini.core.lab11;

public interface Lab11_4_InterfaceLamda
{
	public abstract LambdaImpll_11_4 getLambdaImpll_11_4(int id , String name , int age);
}
