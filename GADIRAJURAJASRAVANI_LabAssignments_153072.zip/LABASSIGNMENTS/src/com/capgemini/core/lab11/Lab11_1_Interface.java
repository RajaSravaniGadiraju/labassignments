package com.capgemini.core.lab11;

public interface Lab11_1_Interface 
{
	public abstract double exponential(int x,int y);
}
