package com.capgemini.core.lab11;

public interface Lab11_2_Interface
{
	public abstract String modifyString(String str);
}
