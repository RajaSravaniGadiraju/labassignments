package com.capgemini.core.lab8;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyDataThread implements Runnable 
{
@Override
    public void run() 
        {
		  try
		    {
			  FileReader input=new FileReader("D:\\source.txt");
			  FileWriter output=new FileWriter("D:\\target.txt");
			  int a,counts=0;
			  while((a=input.read())!=-1)
			   {
				  output.write(a);
				  counts++;
				  if(counts%10==0)
				  {
					System.out.println("10 char copied");
					Thread.sleep(5000);
					
				  }
			 }
			input.close();
			output.close();
		 }
		 catch(Exception e)
		
		 {
			e.printStackTrace();
		 }
	 }
 }
