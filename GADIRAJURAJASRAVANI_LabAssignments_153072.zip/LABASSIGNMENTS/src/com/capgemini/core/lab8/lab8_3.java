package com.capgemini.core.lab8;



import java.util.Random;
import java.util.Scanner;

public class lab8_3 implements Runnable
{
	int num;
	public lab8_3(int num)
	
	{
		super();
		this.num=num;
	}
	
	@Override
	public void run() {
		System.out.println("Number is "+ num);
		
	}
	public static void main(String[] args) throws InterruptedException {
		lab8_3factorial factorial;
		lab8_3factorial number1;
		Thread t1,t2;
		Random r=new Random();
		int number;
		for(int i=0;i<3;i++)
		{
			number=Math.abs(r.nextInt(5));
			number1=new lab8_3factorial(number);
			t1=new Thread(number1);
			t1.start();
			t1.join();
			factorial=new lab8_3factorial(number);
			t2=new Thread(factorial);
			t2.start();
		}
	}
}