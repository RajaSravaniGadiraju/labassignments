package com.capgemini.core.lab8;

public class lab8_3factorial implements Runnable
	{
		int number;
		public lab8_3factorial(int num)
		
		{
			super();
			this.number=num;
		}
		@Override
		public void run() {
		int factorial=1;
		for(int i=1;i<=number;i++)
		{
			factorial=factorial*i;
			}
		System.out.println("Factorial is " +factorial);
			
		}
		
		
	}

