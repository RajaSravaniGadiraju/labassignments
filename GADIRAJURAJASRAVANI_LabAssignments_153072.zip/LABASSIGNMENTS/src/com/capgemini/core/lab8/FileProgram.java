package com.capgemini.core.lab8;

public class FileProgram 
{
	
	public static void main(String[] args)
	{
		CopyDataThread copydata=new CopyDataThread();
		Thread thread=new Thread(copydata);
		thread.start();
	}
}


