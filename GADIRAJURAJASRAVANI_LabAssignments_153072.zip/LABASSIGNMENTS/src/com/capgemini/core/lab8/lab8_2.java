package com.capgemini.core.lab8;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.CompletionException;

public class lab8_2 extends TimerTask

{
@Override
	public void run() 
	{
		System.out.println("Timer task starts at : " + new Date());
		completeTask();
		System.out.println("Timer task ends at : " + new Date());
		
	}
	private void completeTask()
	{
		try
		{
			//assume that it is taking 20 seconds to complete the task
			Thread.sleep(20000);
			
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		lab8_2 task=new lab8_2();
		Timer timer=new Timer(true);
		timer.scheduleAtFixedRate(task, 0, 10*1000);
		System.out.println("Timer task starts");
		try
		{
			Thread.sleep(120000);
			
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	timer.cancel();
	System.out.println("TimerTask cancelled");
	try
	{
		Thread.sleep(30000);
		
	}
	catch(InterruptedException e)
	{
		e.printStackTrace();
	}
		
	}

}
