package com.capgemini.core.lab8;
public class MyFactory 
{
public static void main(String[] args)
	{
       lab8_4 str = new lab8_4();
		Thread thread1 = new Thread() {
			@Override
			public void run() {
				str.Customer();

			}
		};
		Thread thread2 = new Thread() {
			public void run() {
				str.Producer();
			}
		};
		thread1.start();
		thread2.start();

	}
}
