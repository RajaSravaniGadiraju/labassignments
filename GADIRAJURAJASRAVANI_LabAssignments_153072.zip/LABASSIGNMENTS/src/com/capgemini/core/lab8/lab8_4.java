package com.capgemini.core.lab8;



//import com.capgemini.core.lab8.lab8_4.Consumer;
//import com.capgemini.core.lab8.lab8_4.Producer;

class lab8_4
{
	synchronized void Customer()
	{
		Thread thread=Thread.currentThread();
		System.out.println("Customer giving products to billing pesron");
		try
		{
			wait();
			
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		
	}
	synchronized void Producer()
	{
		Thread thread=Thread.currentThread();
		try
		{
			Thread.sleep(1000);
			
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		notify();
		System.out.println("Billing person bills the products");
	}
}
