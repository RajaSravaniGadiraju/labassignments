package com.capgemini.core.lab10;


//Lab 10.2
public class Date10_2_2 {
	int intDay;
	int intMonth;
	int intYear;
	

	public Date10_2_2() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	Date10_2_2(int intDay, int intMonth, int intYear) {
		this.intDay = intDay;
		this.intMonth = intMonth;
		this.intYear = intYear;
	}

	
	void setDay(int intDay) {
		this.intDay = intDay;
	}

	int getDay() {
		return this.intDay;
	}

	void setMonth(int intMonth) {
		this.intMonth = intMonth;
	}

	int getMonth() {
		return this.intMonth;
	}

	void setYear(int intYear) {
		this.intYear = intYear;
	}

	int getYear() {
		return this.intYear;
	}

	public String toString() 
	{
		return "Date is" + intDay + "/" + intMonth + "/" + intYear;
	}
}