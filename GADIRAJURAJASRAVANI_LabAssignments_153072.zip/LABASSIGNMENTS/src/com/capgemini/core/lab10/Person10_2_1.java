package com.capgemini.core.lab10;

public class Person10_2_1 {
	String firstName;
	String lastName;
	char gender;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public Person10_2_1(String firstName, String lastName, char gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
	}

	public Person10_2_1() {
		//super();
		this.firstName="XXX";
		this.lastName="XX";
		this.gender='X';
		
	}

	@Override
	public String toString() {
		return "Person Details\n_________\n" + "\nFirst Name:" + firstName + "\n" +  "Last Name:" + lastName
				+ "\n" +   "gender:" + gender;
	}
	
	public static void main(String[] args) {
		Person10_2_1 p=new Person10_2_1("Sravani","Gadiraju",'F');
		System.out.println(p);
	}
	
	

	

}


