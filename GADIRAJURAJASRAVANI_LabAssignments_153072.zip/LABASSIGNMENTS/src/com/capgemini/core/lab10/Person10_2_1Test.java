package com.capgemini.core.lab10;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class Person10_2_1Test {
private static Person10_2_1 person10_2_1;
	@BeforeClass
	
		public static void initialize()
		{
			person10_2_1=new Person10_2_1("Sravani","Gadiraju",'F');
			
		}
	
	@Test
	public void testSetFirstName()
	{

		person10_2_1.setFirstName("Sravani");
		assertEquals("Sravani", person10_2_1.getFirstName());
	}
	@Test
	public void testSetLastName()
	{

		//person.setLastName("Gadiraju");
		assertEquals("Gadiraju", person10_2_1.getLastName());
	}
	@Test
	public void testSetGender()
	{

		//person.setGender('F');
		assertEquals('F', person10_2_1.getGender());
	}
	
	

}
