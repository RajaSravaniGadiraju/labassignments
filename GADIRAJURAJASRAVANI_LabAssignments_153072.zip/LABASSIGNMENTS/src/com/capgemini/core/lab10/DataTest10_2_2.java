package com.capgemini.core.lab10;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class DataTest10_2_2 {

	
	private static Date10_2_2 date10_2_2;
	@BeforeClass
	public static void testInitialize()
	{
		date10_2_2=new Date10_2_2(26, 9, 1998);
	}
	@Test
	public void testSetDay()
	{
		date10_2_2.setDay(25);
		assertEquals(25, date10_2_2.getDay());
	}
	@Test
	public void testSetMonth()
	{
		date10_2_2.setDay(9);
		assertEquals(9, date10_2_2.getMonth());
	}
	@Test
	public void testSetYear()
	{
		date10_2_2.setDay(1995);
		assertEquals(1995, date10_2_2.getDay());
	}
	
}
